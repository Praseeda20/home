package com.cg.olg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.validator.internal.util.privilegedactions.GetAnnotationParameter;

import com.cg.olg.bean.OnlineGamingBean;
import com.cg.olg.exception.GamingException;
import com.cg.olg.service.OnlineGamingService;
import com.cg.olg.service.OnlineGamingServiceImpl;

/**
 * Servlet implementation class OnlineGamingController
 */
@WebServlet({ "/OnlineGamingController", "/viewAllGames", "/bookGames" ,"/bookForm"})
public class OnlineGamingController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	OnlineGamingService gameService = new OnlineGamingServiceImpl();
	
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public OnlineGamingController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession(true); // Session set to true
		String path = request.getServletPath().trim();
		String target = "";
		switch (path) {
		case "/viewAllGames":
			List<OnlineGamingBean> gameList = null;
			try {
				gameList = gameService.viewAllGames();
				session.setAttribute("gameList", gameList);
				target = "viewAllGames.jsp";
			} catch (GamingException e) {
				e.printStackTrace();
			}
		
			RequestDispatcher dispatcher = request.getRequestDispatcher(target);
			dispatcher.forward(request, response);
			break;
			
			
		case "/bookGames":
			try {
				String gameId=request.getParameter("gameId");
				OnlineGamingBean  bean = gameService.bookGame(gameId);
				System.out.println("ok");
				request.setAttribute("bean", bean);
				target="bookGame.jsp";
			} catch (GamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("ok");
			RequestDispatcher dispatcher1 = request.getRequestDispatcher(target);
			dispatcher1.forward(request, response);
			break;
		
			
		case "/bookForm":
			try {
				int txtNoOfSlots = Integer.parseInt(request.getParameter("txtNoOfSlots"));
				int slot=Integer.parseInt(request.getParameter("txtSlots"));
				System.out.println(txtNoOfSlots);
				String gameId = request.getParameter("txtgameId");
				slot = slot - txtNoOfSlots;
				gameService.updateSlots(slot, gameId);
				float price=gameService.showPrice(gameId);
				float totalPrice=price * txtNoOfSlots;
				session.setAttribute("totalPrice",totalPrice);
				target="bookForm.jsp";
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (GamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			RequestDispatcher dispatcher2 = request.getRequestDispatcher(target);
			dispatcher2.forward(request, response);
			break;
		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
