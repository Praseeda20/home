package com.cg.olg.service;

import java.util.ArrayList;

import com.cg.olg.bean.OnlineGamingBean;
import com.cg.olg.dao.OnlineGamingDao;
import com.cg.olg.dao.OnlineGamingDaoImpl;
import com.cg.olg.exception.GamingException;

public class OnlineGamingServiceImpl implements OnlineGamingService{
	
	OnlineGamingDao gamingDao = new OnlineGamingDaoImpl();
	OnlineGamingBean bean = new OnlineGamingBean();
	
	@Override
	public ArrayList<OnlineGamingBean> viewAllGames()
			throws GamingException {	
		return gamingDao.viewAllGames();
	}

	@Override
	public OnlineGamingBean bookGame(String gameId) throws GamingException {
		return gamingDao.bookGame(gameId);
	}

	@Override
	public float showPrice(String gameId) throws GamingException {
		return gamingDao.showPrice(gameId);	
	}

	@Override
	public void updateSlots(int slot, String gameId) throws GamingException {
		gamingDao.updateSlots(slot, gameId);
	}
	


}
