package com.cg.olg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;








import com.cg.olg.bean.OnlineGamingBean;
import com.cg.olg.exception.GamingException;
import com.cg.olg.util.DBUtil;

public class OnlineGamingDaoImpl implements OnlineGamingDao{
Connection connection;
OnlineGamingBean bean = new OnlineGamingBean();	
	

@Override
	public ArrayList<OnlineGamingBean> viewAllGames()
			throws GamingException {
		connection=DBUtil.obtainConnection();
		Statement statement = null;
		ResultSet resultSet = null;
		String query = "SELECT * FROM onlinegaming";
		ArrayList<OnlineGamingBean> gameList = new ArrayList<OnlineGamingBean>();
		
		try {			
			statement = connection.createStatement();
			resultSet = statement.executeQuery(query);
			//fetch details if result set is not null
			while(resultSet.next())
			{
				System.out.println("Resultset coming");
				bean = new OnlineGamingBean();
				bean.setGameId(String.valueOf(resultSet.getString(1)));
				bean.setGameName(resultSet.getString(2));
				bean.setPrice(resultSet.getFloat(3));
				bean.setSlot(resultSet.getInt(4));
				gameList.add(bean);				
			}			
		} catch (Exception e) {			
			throw new GamingException("something went wrong while fetching stock details...");
		}		
		return gameList;

	}


	@Override
	public OnlineGamingBean bookGame(String gameId) throws GamingException {
		connection=DBUtil.obtainConnection();
		String query = "select * from onlinegaming where gameId=?";
		System.out.println("1");
		ResultSet resultSet = null;
		try{
			PreparedStatement pst = connection.prepareStatement(query);
			System.out.println("2");
			pst.setString(1, gameId);
			resultSet = pst.executeQuery() ;
			System.out.println("3");
			resultSet.next() ;
			bean.setGameId(resultSet.getString(1));
			bean.setGameName(resultSet.getString(2));
			bean.setPrice(resultSet.getFloat(3));
			bean.setSlot(resultSet.getInt(4));
			System.out.println(bean);
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	
		return bean;
	}

	@Override
	public void updateSlots(int slot , String gameId) throws GamingException 
	{
		try
		{
			connection = DBUtil.obtainConnection() ;
			String query = "update onlinegaming set slot=? where gameId=?";
			PreparedStatement pst = connection.prepareStatement(query);
			pst.setInt(1, slot);
			pst.setString(2, gameId);
			pst.executeUpdate();
		}
		catch(SQLException e)
		{
			//e.printStackTrace();
			throw new GamingException("Problem while updating the table");
		}
	}

	@Override
	public float showPrice(String gameId) throws GamingException {
		connection = DBUtil.obtainConnection() ;
		float price=0;
		ResultSet resultSet = null;
		try {
			String query = "select price from onlinegaming where gameId=?";
			PreparedStatement pst = connection.prepareStatement(query);
			pst.setString(1, gameId);
			resultSet = pst.executeQuery();
			resultSet.next() ;
			price = bean.setPrice(resultSet.getFloat(1));
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return price;
		
	}

}
